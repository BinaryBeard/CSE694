#pragma strict

function Start () {

}

function Update () {

}

function Awake () {

    DontDestroyOnLoad (this);
}
